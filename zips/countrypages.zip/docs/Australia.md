# Australia (AU)

<table width="90%">
<tr>
<td>
<img src="http://commons.wikimedia.org/wiki/Special:FilePath/Flag%20of%20Australia%20%28converted%29.svg" width="250">
<br><br>
<img src="http://commons.wikimedia.org/wiki/Special:FilePath/AUS%20orthographic.svg" width="250"></td>
<td>
<h3>Country characteristics</h3>
<div style="display: inline-block;text-align:right;margin-right:30px;font-weight: bold;">
Continent:<br>Population:<br>Area:<br>GDP (USD billions):
</div>
<div style="display: inline-block;">
Oceania<br>26,473,055<br>7,692,024 km2<br>1728.1 B$
</div>
<h3>Electrical network mapped on OpenStreetMap</h3>
<div style="display: inline-block;text-align:right;margin-right:30px;font-weight: bold;">Generation capacity:<br>
Number of power plants:<br>
Number of substations:<br>
Power line length:<br>
International connections:<br>
</div>
<div style="display: inline-block;">75031 MW<br>
758<br>
<br>
120536 km<br>
<br>
</div>

<br><br><h4>See also :
<a href="https://wiki.openstreetmap.org/wiki/Power_networks/Australia" target="_blank">OSM wiki page</a> -
<a href="https://openstreetmap.org/relation/80500" target="_blank">OSM country shape</a>
</h4>

<br><i>data from Wikidata and OpenInfraMap</i>
</td>
</tr>
</table>




