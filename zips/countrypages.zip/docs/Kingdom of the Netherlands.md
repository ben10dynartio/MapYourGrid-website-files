# Kingdom of the Netherlands (NL)

<table width="90%">
<tr>
<td>
<img src="http://commons.wikimedia.org/wiki/Special:FilePath/Flag%20of%20the%20Netherlands.svg" width="250">
<br><br>
<img src="http://commons.wikimedia.org/wiki/Special:FilePath/Kingdom%20of%20the%20Netherlands%20in%20its%20region%20%28special%20marker%29.svg" width="250"></td>
<td>
<h3>Country characteristics</h3>
<div style="display: inline-block;text-align:right;margin-right:30px;font-weight: bold;">
Continent:<br>Population:<br>Area:<br>GDP (USD billions):
</div>
<div style="display: inline-block;">
Europe<br>17,100,715<br>42,201 km2<br> B$
</div>
<h3>Electrical network mapped on OpenStreetMap</h3>
<div style="display: inline-block;text-align:right;margin-right:30px;font-weight: bold;">Generation capacity:<br>
Number of power plants:<br>
Number of substations:<br>
Power line length:<br>
International connections:<br>
</div>
<div style="display: inline-block;">38052 MW<br>
1035<br>
<br>
8118 km<br>
<br>
</div>

<br><br><h4>See also :
<a href="https://wiki.openstreetmap.org/wiki/Power_networks/Kingdom of the Netherlands" target="_blank">OSM wiki page</a> -
<a href="https://openstreetmap.org/relation/2323309" target="_blank">OSM country shape</a>
</h4>

<br><i>data from Wikidata and OpenInfraMap</i>
</td>
</tr>
</table>




