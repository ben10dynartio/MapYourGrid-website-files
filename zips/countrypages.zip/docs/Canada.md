# Canada (CA)

<table width="90%">
<tr>
<td>
<img src="http://commons.wikimedia.org/wiki/Special:FilePath/Flag%20of%20Canada%20%28Pantone%29.svg" width="250">
<br><br>
<img src="http://commons.wikimedia.org/wiki/Special:FilePath/CAN%20orthographic.svg" width="250"></td>
<td>
<h3>Country characteristics</h3>
<div style="display: inline-block;text-align:right;margin-right:30px;font-weight: bold;">
Continent:<br>Population:<br>Area:<br>GDP (USD billions):
</div>
<div style="display: inline-block;">
North America<br>40,000,000<br>9,984,670 km2<br>2206.8 B$
</div>
<h3>Electrical network mapped on OpenStreetMap</h3>
<div style="display: inline-block;text-align:right;margin-right:30px;font-weight: bold;">Generation capacity:<br>
Number of power plants:<br>
Number of substations:<br>
Power line length:<br>
International connections:<br>
</div>
<div style="display: inline-block;">138954 MW<br>
1129<br>
<br>
186990 km<br>
<br>
</div>

<br><br><h4>See also :
<a href="https://wiki.openstreetmap.org/wiki/Power_networks/Canada" target="_blank">OSM wiki page</a> -
<a href="https://openstreetmap.org/relation/1428125" target="_blank">OSM country shape</a>
</h4>

<br><i>data from Wikidata and OpenInfraMap</i>
</td>
</tr>
</table>




