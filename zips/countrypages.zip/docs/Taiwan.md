# Taiwan (TW)

<table width="90%">
<tr>
<td>
<img src="http://commons.wikimedia.org/wiki/Special:FilePath/Flag%20of%20the%20Republic%20of%20China.svg" width="250">
<br><br>
<img src="http://commons.wikimedia.org/wiki/Special:FilePath/Locator%20map%20of%20the%20ROC%20Taiwan.svg" width="250"></td>
<td>
<h3>Country characteristics</h3>
<div style="display: inline-block;text-align:right;margin-right:30px;font-weight: bold;">
Continent:<br>Population:<br>Area:<br>GDP (USD billions):
</div>
<div style="display: inline-block;">
Asia<br>23,409,323<br>36,193 km2<br> B$
</div>
<h3>Electrical network mapped on OpenStreetMap</h3>
<div style="display: inline-block;text-align:right;margin-right:30px;font-weight: bold;">Generation capacity:<br>
Number of power plants:<br>
Number of substations:<br>
Power line length:<br>
International connections:<br>
</div>
<div style="display: inline-block;">54176 MW<br>
326<br>
<br>
7501 km<br>
<br>
</div>

<br><br><h4>See also :
<a href="https://wiki.openstreetmap.org/wiki/Power_networks/Taiwan" target="_blank">OSM wiki page</a> -
<a href="https://openstreetmap.org/relation/449220" target="_blank">OSM country shape</a>
</h4>

<br><i>data from Wikidata and OpenInfraMap</i>
</td>
</tr>
</table>




